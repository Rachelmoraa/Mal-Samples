PE/Compress, version 1.0,
Copyright (c) 2005, Michal Strehovsky,
www.migeel.sk, mail@migeel.sk
ICQ: 140294388


WHAT IS PE/COMPRESS?
====================

PE/Compress is a 32bit Windows PE-EXE file compressor. It reduces the executable file size by around 50-30%, thus reducing storage costs and download times.
Every compressed program is self-contained. It means that no other software is needed for the application to be decompressed and executed. The compressed programs run exactly as before.
PE/Compress was tested with Windows 95 and Windows XP and should run with Windows 98/Me/NT4/2000 also.
PE/Compress is FREEWARE. It means, you can use it freely for both commercial and non-commercial purposes.


SHORT DOCUMENTATION
===================

The program is operated through command line parameters. Sorry, no GUI this time (I wanted to keep the code as short as possible).

  PECompress SourceFile.exe [-Ratio] [-o OutputFile.exe]

Ratio is a compression ratio from 1 to 9 (5 is default, 9 is highest).
Switch -o specifies output file (input file name used by default).

The line:
  PECompress Source.exe -9 -o Destination.exe
Will compress Source.exe with compression ratio of 9 (best) and save the result to Destination.exe.


FOR PROGRAMMERS
===============

PE/Compress is a demonstration program, demonstrating the capabilities of PE-Inject library. PE-Inject is a special library for injecting foreign code into portable executable files (shortly: PE files - EXE, DLL, OCX, etc.)
PE-Inject makes injection of the code really easy. You can forget about all the obvious assembler stuff because no assember knowledge is needed. You can write your own EXE compression, encryption, protection, etc. programs even with Visual Basic (not really tested, but it should work).
The principle is really easy: you make your own DLL file containing all the functions you want to be executed when the injected EXE is started. PE-Inject merges your DLL file with other neccessary code and injects the result into target EXE.
PE/Compress was made using PE-Inject library in less than 5 hours (plus about 8 hours work on resource compression support) and the resulting source code (including all the user interaction stuff) has less than 200 lines of code (resource support makes it a little bigger)!
Programming EXE modification engines has never been easyer before.

For more information about PE-Inject engine, just visit http://www.migeel.sk/peinject

